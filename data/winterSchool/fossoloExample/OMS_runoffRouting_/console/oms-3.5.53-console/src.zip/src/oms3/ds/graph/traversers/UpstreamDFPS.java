/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3.ds.graph.traversers;

import java.util.ArrayDeque;
import java.util.Set;
import oms3.ds.graph.DiGraph;

/**
 *
 * @author sidereus
 */
class UpstreamDFPS extends SearchDirection {

	protected UpstreamDFPS(AlgorithmDS algoDS) {
		this.algoDS = algoDS;
	}

	@Override
	protected Set<Integer> getNeighbourhood(Integer vertex, DiGraph graph) {
		return graph.getChildren(vertex);
	}

	@Override
	protected void allocatePath() {
		path = new ArrayDeque<>();
	}

	@Override
	protected void addToPath(Integer vertex) {
		path.add(vertex);
	}

}
