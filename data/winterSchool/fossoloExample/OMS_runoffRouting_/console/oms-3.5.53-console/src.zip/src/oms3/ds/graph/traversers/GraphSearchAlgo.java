/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3.ds.graph.traversers;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import oms3.ds.graph.DiGraph;

/**
 *
 * @author sidereus
 */
public abstract class GraphSearchAlgo {
	
	private Map<Integer, Integer> edgeTo;
	private Map<Integer, Boolean> marked;
	private SearchDirection searchDir;
	private Integer source;

	public void compute(String direction, Integer source, DiGraph graph) {
		initialize(graph, source);
		searchDir = buildAlgo(direction);

		marked.put(source, Boolean.TRUE);
		searchDir.add(source);
		while(!searchDir.isDone()) {
			Integer vertex = searchDir.delete();
			searchDir.getNeighbourhood(vertex, graph).forEach(neighbour -> {
				if (!marked.get(neighbour)) {
					edgeTo.put(neighbour, vertex);
					marked.put(neighbour, Boolean.TRUE);
					searchDir.add(neighbour);
				}
			});
		}
	}

	private void initialize(DiGraph graph, Integer source) {
		this.source = source;
		this.edgeTo = new ConcurrentHashMap<>();
		this.marked = new ConcurrentHashMap<>();
		graph.getVertecesIndeces().forEach(index -> {
			this.marked.put(index, Boolean.FALSE);
		});
	}

	public Boolean hasPathTo(Integer vertex) {
		return marked.get(vertex);
	}

	public Iterator<Integer> pathTo(Integer vertex) {
		if (!hasPathTo(vertex)) return null;

		searchDir.allocatePath();
		for(int i=vertex; i != source; i = edgeTo.get(i)) {
			searchDir.addToPath(i);
		}
		searchDir.addToPath(source);
		return searchDir.getPath().iterator();
	}

	abstract protected SearchDirection buildAlgo(String direction);

}