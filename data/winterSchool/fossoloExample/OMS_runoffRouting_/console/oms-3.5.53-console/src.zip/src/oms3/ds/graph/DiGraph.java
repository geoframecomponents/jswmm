/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3.ds.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author Francesco Serafin
 */
public class DiGraph {
	
    Map<Integer, Object> vertices;
    Map<Integer, Family> edges;

    public DiGraph() {
        vertices = new ConcurrentHashMap<>();
        edges = new ConcurrentHashMap<>();
    }

    public Object get(Integer index) {
        return vertices.get(index);
    }

    public void addVertex(Integer key, Object value) {
        if (key != 0)
            vertices.putIfAbsent(key, value);
    }

	public void addConnection(Integer parent, Integer child) {
		addParent(parent, child);
		addChild(parent, child);
	}

	public Integer outDegree(Integer vertex) {
		precondition();
		return edges.get(vertex).parentsNumber();
	}

	public Integer inDegree(Integer vertex) {
		precondition();
		return edges.get(vertex).childrenNumber();
	}

	public DiGraph reverse() {
		precondition();
		DiGraph reversedDiGraph = new DiGraph();
		edges.keySet().forEach(vertex -> {
			Set<Integer> formerChildren = edges.get(vertex).children;
			formerChildren.forEach((newParent) -> {
				reversedDiGraph.addConnection(newParent, vertex);
			});
		});
		reversedDiGraph.addVerteces(vertices);
		return reversedDiGraph;
	}

	public Set<Integer> getChildren(Integer vertex) {
		precondition();
		return edges.get(vertex).children;
	}

	public Set<Integer> getParents(Integer vertex) {
		precondition();
		return edges.get(vertex).parents;
	}

	public Set<Integer> getVertecesIndeces() {
		return vertices.keySet();
	}

    public void parentNotice(Integer vertex) {
        edges.get(vertex).parents.forEach(parent -> {
            HashMap<Integer, Boolean> hm = (HashMap<Integer, Boolean>) vertices.get(parent);
            hm.replace(vertex, Boolean.TRUE);
            vertices.replace(parent, hm);
        });

    }

    public boolean readyForSim(Integer vertex) {
        return !((HashMap<Integer, Boolean>)vertices.get(vertex)).containsValue(false);
    }

    public void initialize() {
        vertices.keySet().forEach((vertex) -> {
            Family fam = edges.get(vertex);
            HashMap<Integer, Boolean> hm = (HashMap) vertices.get(vertex);
            if (fam.childrenNumber() != 0) {
                for (Integer child : fam.children) {
                    hm.put(child, Boolean.FALSE);
                }
            } else {
                hm.put(0, Boolean.TRUE);
            }
            vertices.replace(vertex, hm);
        });
    }

    public void initialize(Set<Integer> path) {
        vertices.keySet().forEach((vertex) -> {
            Family fam = edges.get(vertex);
            HashMap<Integer, Boolean> hm = (HashMap) vertices.get(vertex);
            if (fam.childrenNumber() != 0) {
                for (Integer child : fam.children) {
                    if (path.contains(child))
                        hm.put(child, Boolean.FALSE);
                    else
                        hm.put(child, Boolean.TRUE);
                }
            } else {
                hm.put(0, Boolean.TRUE);
            }
            vertices.replace(vertex, hm);
        });
    }
    
    public List<Integer> subTreePostOrder(int vertex) {
        List<Integer> vertices = new ArrayList<>();
        Family fam = edges.get(vertex);
        ordering(fam, vertices);
        vertices.add(vertex);
        return vertices;
    }
    
    private void ordering(Family family, List<Integer> vertices) {
        for(Integer child : family.children) {
            Family childFamily = edges.get(child);
            ordering(childFamily, vertices);
            vertices.add(child);
        }
    }

	private void addVerteces(Map<Integer, Object> vertices) {
		this.vertices = vertices;
	}

	private void addParent(Integer parent, Integer child) {
		Family family = (edges.containsKey(child)) ? edges.get(child) : new Family();
		family.addParent(parent);
		edges.put(child, family);
	}

	private void addChild(Integer parent, Integer child) {
		if (parent == 0) return;
		Family family = (edges.containsKey(parent)) ? edges.get(parent) : new Family();
		family.addChild(child);
		edges.put(parent, family);
	}

	private void precondition() {
		if (vertices.size() != edges.size()) {
			String msg = "Verteces size: " + vertices.size() + "\n";
			msg += "Edges size: " + edges.size() + "\n";
			msg += "You cannot retrive data from the graph, it has" +
				"not been completely built yet.";
			throw new RuntimeException(msg);
		}
	}

	private class Family {
		private final Set<Integer> parents;
		private final Set<Integer> children;
		private boolean root = false;

		public Family() {
			parents = new HashSet<>();
			children = new HashSet<>();
		}

		public void addChild(Integer child) {
			children.add(child);
		}

		/**
		 * 0 cannot be add as a parent, because who's parent is 0 is the
		 * root
		 * @param parent 
		 */
		public void addParent(Integer parent) {
			if (parent == 0) {
				root = true;
				return;
			}

			parents.add(parent);
		}

		private Integer childrenNumber() {
			return children.size();
		}

		private Integer parentsNumber() {
			return parents.size();
		}
	}

	public String toString(Integer vertex) {
		precondition();
		String msg = "Vertex: " + vertex + "\n";
		msg += "Children: ";
		msg = edges.get(vertex).children.stream().map((child) -> child + " ").reduce(msg, String::concat);
		msg += "\nParents: ";
		msg = edges.get(vertex).parents.stream().map((parent) -> parent + " ").reduce(msg, String::concat);
		msg += "\n";
		return msg;
	}

}