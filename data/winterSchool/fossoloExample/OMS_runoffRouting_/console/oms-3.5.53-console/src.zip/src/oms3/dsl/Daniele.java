/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oms3.dsl;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sidereus
 */
public class Daniele implements Buildable {
    
    public Map<String, Object> tobuffer = new HashMap();

    @Override
    public Buildable create(Object name, Object value) {
        tobuffer.put((String)name, value);
        return LEAF;
    }

}
